//
// Created by galje on 5/24/2022.
//

#ifndef NALOGA_0501_COPIER_H
#define NALOGA_0501_COPIER_H


class Copier {
protected:
    int maxPrintSpeed;
public:
    Copier(int maxPrintSpeed):maxPrintSpeed(maxPrintSpeed){};
};


#endif //NALOGA_0501_COPIER_H
