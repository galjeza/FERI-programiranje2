//
// Created by galje on 5/24/2022.
//

#ifndef NALOGA_0501_SCANNER_H
#define NALOGA_0501_SCANNER_H


class Scanner {
protected:
    int dots_per_inch;
public:
    Scanner(int dots): dots_per_inch(dots){};
};


#endif //NALOGA_0501_SCANNER_H
