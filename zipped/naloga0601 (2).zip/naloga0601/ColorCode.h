//
// Created by galje on 4/1/2022.
//

#ifndef NALOGA0601_COLORCODE_H
#define NALOGA0601_COLORCODE_H


enum class ColorCode {
    Red = 31,
    Green = 32,
    Blue = 34,
    Default = 39

};


#endif //NALOGA0601_COLORCODE_H
