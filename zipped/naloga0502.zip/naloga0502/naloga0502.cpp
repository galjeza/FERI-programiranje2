#include <iostream>
#include "SmartHome.h"
#include "Device.h"
#include "Phone.h"
#include "TV.h"
#include "Light.h"
int main() {
    SmartHome smartHome("Gal's Home");
    Device * smartPhone = new Phone("927a4as56","iPhone 7",73);
    Device * smartTv = new TV("8d45a630s2","Samsung Smart TV",true,23);
    Device * light = new Light("193rz2764i6","Bathroom Light",false);
    smartHome.addDevice(smartPhone);
    smartHome.addDevice(smartTv);
    smartHome.addDevice(light);
    smartHome.addDevice(new Device("37a3r46e1","unknown device"));
    std::cout<<smartHome.toString();


    return 0;
}
