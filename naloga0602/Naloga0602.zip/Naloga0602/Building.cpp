#include "Building.h"

Building::Building(std::string address):address(address)
{
}

void Building::print() const
{
}

std::string Building::toString() const
{
	return "";
}
